package com.example.admin.finalwakeupme;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/**
 * Created by Admin on 2018-06-05.
 */

public class LockScreenPage extends AppCompatActivity {
    Random rnd = new Random();
    int a, b = 0;
    int a1, b1 = 0;
    int a2, b2 = 0;
    int a3, b3 = 0;
    String c = "";
    String c1 = "";
    String c2 = "";
    String c3 = "";
    TextView tx, tx1, tx2, tx3;
    EditText et, et1, et2, et3;
    Button btn;
    int d,d1,d2,d3=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lockpage);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        btn = (Button) findViewById(R.id.btn);
        tx = (TextView) findViewById(R.id.tx1);
        tx1 = (TextView) findViewById(R.id.tx2);
        tx2 = (TextView) findViewById(R.id.tx3);
        tx3 = (TextView) findViewById(R.id.tx4);
        et = (EditText) findViewById(R.id.et1);
        et1 = (EditText) findViewById(R.id.et2);
        et2 = (EditText) findViewById(R.id.et3);
        et3 = (EditText) findViewById(R.id.et4);


        Typeface face = Typeface.createFromAsset(getAssets(), "fonts/itgirl.ttf");
        btn.setTypeface(face);
        tx.setTypeface(face);
        tx1.setTypeface(face);
        tx2.setTypeface(face);
        tx3.setTypeface(face);
        et.setTypeface(face);
        et1.setTypeface(face);
        et2.setTypeface(face);
        et3.setTypeface(face);


        a = rnd.nextInt(1000000000);
        String randomStr = String.valueOf(a);


        a1 = rnd.nextInt(330001000);
        String randomStr1 = String.valueOf(a1);


        a2 = rnd.nextInt(455000000);
        String randomStr2 = String.valueOf(a2);


        a3 = rnd.nextInt(100000450);
        String randomStr3 = String.valueOf(a3);



        tx.setText(randomStr);
        tx1.setText(randomStr1);
        tx2.setText(randomStr2);
        tx3.setText(randomStr3);



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (!et.getText().toString().equals("")) {
                        c = et.getText().toString();
                        b = Integer.parseInt(c);

                        if (a == b) {
                           /* Intent intent = new Intent(getApplicationContext(), MyService.class);
                            stopService(intent);

                            Toast.makeText(getApplicationContext(), "알람해제", Toast.LENGTH_LONG).show();

                            Intent intent1 = new Intent(LockScreenPage.this, MainActivity1.class);
                            startActivity(intent1);
                            finish();*/
                           d=1;

                        } else {
                            Toast.makeText(getApplicationContext(), "1번쨰 것을 재입력하세요", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "수를 입력하세요", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Toast.makeText(getApplicationContext(), "수를 입력하세요", Toast.LENGTH_SHORT).show();
                }


                try {
                    if (!et1.getText().toString().equals("")) {
                        c1 = et1.getText().toString();
                        b1 = Integer.parseInt(c1);

                        if (a1 == b1) {
                       /*     Intent intent = new Intent(getApplicationContext(), MyService.class);
                            stopService(intent);

                            Toast.makeText(getApplicationContext(), "알람해제", Toast.LENGTH_LONG).show();

                            Intent intent1 = new Intent(LockScreenPage.this, MainActivity1.class);
                            startActivity(intent1);
                            finish();*/
                       d1=1;

                        } else {
                            Toast.makeText(getApplicationContext(), "2번쨰 것을 재입력하세요", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "수를 입력하세요", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Toast.makeText(getApplicationContext(), "수를 입력하세요", Toast.LENGTH_SHORT).show();
                }


                try {
                    if (!et2.getText().toString().equals("")) {
                        c2 = et2.getText().toString();
                        b2 = Integer.parseInt(c2);

                        if (a2 == b2) {
                          /*  Intent intent = new Intent(getApplicationContext(), MyService.class);
                            stopService(intent);

                            Toast.makeText(getApplicationContext(), "알람해제", Toast.LENGTH_LONG).show();

                            Intent intent1 = new Intent(LockScreenPage.this, MainActivity1.class);
                            startActivity(intent1);
                            finish();*/
                          d2=1;

                        } else {
                            Toast.makeText(getApplicationContext(), "3번쨰 것을 재입력하세요", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "수를 입력하세요", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Toast.makeText(getApplicationContext(), "수를 입력하세요", Toast.LENGTH_SHORT).show();
                }


                try {
                    if (!et3.getText().toString().equals("")) {
                        c3 = et3.getText().toString();
                        b3 = Integer.parseInt(c3);

                        if (a3 == b3) {
                         /*   Intent intent = new Intent(getApplicationContext(), MyService.class);
                            stopService(intent);

                            Toast.makeText(getApplicationContext(), "알람해제", Toast.LENGTH_LONG).show();

                            Intent intent1 = new Intent(LockScreenPage.this, MainActivity1.class);
                            startActivity(intent1);
                            finish();*/
                         d3=1;

                        } else {
                            Toast.makeText(getApplicationContext(), "4번째 것을 재입력하세요", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "수를 입력하세요", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Toast.makeText(getApplicationContext(), "수를 입력하세요", Toast.LENGTH_SHORT).show();
                }

                if(d==1){
                    if(d1==1){
                        if(d2==1){
                            if(d3==1){
                                Intent intent = new Intent(getApplicationContext(), MyService.class);
                                stopService(intent);

                                Toast.makeText(getApplicationContext(), "알람해제", Toast.LENGTH_LONG).show();

                                Intent intent1 = new Intent(LockScreenPage.this, MainActivity1.class);
                                startActivity(intent1);
                                finish();
                            }
                        }
                    }
                }

                 d=0;
                d1=0;
                d2=0;
                d3=0;
            }
        });
    }
/*

    @Override
    public void onAttachedToWindow() {

        super.onAttachedToWindow();

        this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD_DIALOG);

    }

*/

 /* @Override
    protected void onUserLeaveHint(){
        //Toast.makeText(this, "5초뒤 다시 뜹니다.", Toast.LENGTH_LONG).show();
        finish();
        Intent i = new Intent(this,LockScreenPage.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);

        super.onUserLeaveHint();
    } */


    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }
}

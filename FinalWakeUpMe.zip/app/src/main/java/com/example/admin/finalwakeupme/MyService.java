package com.example.admin.finalwakeupme;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Observable;
import java.util.concurrent.TimeUnit;

/**
 * Created by Admin on 2018-05-17.
 */
public class MyService extends Service {

    MediaPlayer mediaPlayer = new MediaPlayer();
    private ArrayList<MusicDto> list;
    int position;
    int valume = 0;
    //long time=0;
    Thread thread;
    int valume123=0;


    IBinder mBinder = new MyBinder();

    class MyBinder extends Binder {
        MyService getService() { // 서비스 객체를 리턴
            return MyService.this;
        }
    }


    @Override
    public IBinder onBind(Intent intent) {

        // time = intent.getLongExtra("time", 0);
        // Service 객체와 (화면단 Activity 사이에서)
        // 통신(데이터를 주고받을) 때 사용하는 메서드
        // 데이터를 전달할 필요가 없으면 return null;
        return mBinder;
    }

    @Override
    public void onCreate() {
        super.onCreate();


    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        Intent intent1 = new Intent(this, LockScreenPage.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent1, PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder builder = new Notification.Builder(this);
        builder.setSmallIcon(R.drawable.rerac1);
        builder.setTicker("알람 해제하기");
        builder.setContentTitle("알람을 해제하세요");
        builder.setContentText("click");
        builder.setWhen(System.currentTimeMillis());
        builder.setContentIntent(pendingIntent);
        builder.setAutoCancel(true);
        Typeface face = Typeface.createFromAsset(getAssets(), "fonts/itgirl.ttf");

        String ns = Context.NOTIFICATION_SERVICE;
        NotificationManager notificationManager = (NotificationManager) this.getSystemService(ns);
        // notificationManager.notify(0,builder.build());


        startForeground(1, builder.build());


        position = intent.getIntExtra("position", 0);
        list = (ArrayList<MusicDto>) intent.getSerializableExtra("playlist");
        valume = intent.getIntExtra("valume", 0);
        valume123 = valume;
        System.out.println(valume + "입니다.");
        //  System.out.println(position);
        // playMusic(list.get(position));



        final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, valume, 0);


        valume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);


        playMusic(list.get(position));

        return super.onStartCommand(intent, flags, startId);
    }




    @Override
    public void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop(); // 음악 종료
        stopForeground(true);
    }

    public void playMusic(MusicDto musicDto) {
        try {

            Uri musicURI = Uri.withAppendedPath(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "" + musicDto.getId());

            mediaPlayer.reset();
            mediaPlayer.setDataSource(this, musicURI);
            mediaPlayer.prepare();
            mediaPlayer.start();


            thread = new Thread() {

                @Override
                public void run() {
                    while (true) {


                        if(valume<16){
                            valume=valume123;
                            final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
                            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, valume, 0);
                            valume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                            System.out.println("TEST");
                        }


                        try {
                            Thread.sleep(1000); // 1000 ms = 1초
                            // 스레드를 1초동안 잠들게 함
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } // while
                } // run()


            };

            // new Thread() { };

            thread.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void startForeground(Service service) {

    }


}




package com.example.admin.finalwakeupme;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;

import java.util.ArrayList;

public class AlarmReceiver extends BroadcastReceiver {

    private ArrayList<MusicDto> list;
    int position;
    int valume;


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public  void onReceive(Context context, Intent intent){










        position = intent.getIntExtra("position", 0);
        list = (ArrayList<MusicDto>) intent.getSerializableExtra("playlist");
        valume = intent.getIntExtra("valume",0);
        Intent mServiceintent = new Intent(context,MyService.class);
        mServiceintent.putExtra("position", position);
        mServiceintent.putExtra("playlist", list);
        mServiceintent.putExtra("valume",valume);
        context.startService(mServiceintent);





    }
}

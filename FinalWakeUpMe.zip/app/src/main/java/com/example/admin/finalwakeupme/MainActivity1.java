package com.example.admin.finalwakeupme;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity1 extends AppCompatActivity {
    Button btn;
    TextView txt1;
    String day = "" ;
    String day1="";
    myDBHelper  myHelper;
    SQLiteDatabase sqlDB;
    Cursor cursor;
    String hours ="";
    String min1 ="";
    TextView dbmon1,dbmon2,dbmon3,dbmon4,dbmon5;
    TextView dbmon11,dbmon12,dbmon13,dbmon14,dbmon15;
    int m1=0;
    int h1=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);

        myHelper = new myDBHelper(MainActivity1.this,"TEST",null,1);

        sqlDB = myHelper.getWritableDatabase();
        myHelper.onUpgrade(sqlDB,1,2);


        txt1 = (TextView) findViewById(R.id.tx1);
        dbmon1 = (TextView)findViewById(R.id.dbmon);
        dbmon2 = (TextView)findViewById(R.id.dbmon1);
        dbmon3 = (TextView)findViewById(R.id.dbmon2);
        dbmon4 = (TextView)findViewById(R.id.dbmon3);
        dbmon5 = (TextView)findViewById(R.id.dbmon4);
        btn = (Button)findViewById(R.id.btn4);

        dbmon11 = (TextView)findViewById(R.id.dbmon11);
        dbmon12 = (TextView)findViewById(R.id.dbmon12);
        dbmon13 = (TextView)findViewById(R.id.dbmon13);
        dbmon14 = (TextView)findViewById(R.id.dbmon14);
        dbmon15 = (TextView)findViewById(R.id.dbmon15);



        Typeface face=Typeface.createFromAsset(getAssets(), "fonts/itgirl.ttf");
        dbmon1.setTypeface(face);
        dbmon2.setTypeface(face);
        dbmon3.setTypeface(face);
        dbmon4.setTypeface(face);
        dbmon5.setTypeface(face);
        dbmon11.setTypeface(face);
        dbmon12.setTypeface(face);
        dbmon13.setTypeface(face);
        dbmon14.setTypeface(face);
        dbmon15.setTypeface(face);
        btn.setTypeface(face);
        txt1.setTypeface(face);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity1.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });



        Date date = new Date(System.currentTimeMillis() + 1000);
        long time = date.getTime();



        Calendar cal1 = Calendar.getInstance();

        int dayNum1 = cal1.get(Calendar.DAY_OF_WEEK) ;

        switch(dayNum1){
            case 1:
                day1 = "일";
                break ;
            case 2:
                day1 = "월";

                break ;
            case 3:
                day1 = "화";

                break ;
            case 4:
                day1 = "수";

                break ;
            case 5:
                day1 = "목";

                break ;
            case 6:
                day1 = "금";

                break ;
            case 7:
                day1 = "토";
                break ;

        }




        Date date1 = new Date(System.currentTimeMillis() + 1000);
        //date.setDate(date.getDate()+1);
        long time1 = date1.getTime();

        Calendar cal = Calendar.getInstance();

        cal.setTimeInMillis(time1);

        int dayNum = cal.get(Calendar.DAY_OF_WEEK) ;



        sqlDB = myHelper.getReadableDatabase();
        cursor = sqlDB.rawQuery("select weekcode from timelist where weekcode = '"+1+"';",null);

        switch(dayNum){
            case 1:
                day = "일";
                break ;
            case 2:
                day = "월";
                sqlDB = myHelper.getReadableDatabase();
                cursor = sqlDB.rawQuery("select hours,minutes from timelist where weekcode = '"+2+"';",null);



                while (cursor.moveToNext()){
                    try {
                        hours = cursor.getString(0);
                        min1 = cursor.getString(1);
                        int m=Integer.parseInt(min1);
                        int h=Integer.parseInt(hours);
                        if(m<0){

                            m1 = -m;
                            for(int i=0;0<m1;i++){
                                h1=h-1;
                                m1 = m1-60;
                            }
                            m1= 60 + m1;

                            if(m1<10&&h1<10){
                                dbmon1.setText("0"+h1+":0"+m1);
                            }else if(m1<10){
                                dbmon1.setText(h1+":0"+m1);
                            }else if(h1<10){
                                dbmon1.setText("0"+h1+":"+m1);
                            }else{
                                dbmon1.setText(h1+":"+m1);
                            }


                        }else{
                            if(m<10&&h<10){
                                dbmon1.setText("0"+h+":0"+m);
                            }else if(m<10){
                                dbmon1.setText(h+":0"+m);
                            }else if(h<10){
                                dbmon1.setText("0"+h+":"+m);
                            }else{
                                dbmon1.setText(h+":"+m);
                            }
                            //   dbmon5.setText(h+":"+m);
                        }

                    }catch (Exception ex){
                        hours = "xx";
                        min1 = "xx";
                    }

                }



                cursor.close();
                sqlDB.close();
                break ;
            case 3:
                day = "화";
                sqlDB = myHelper.getReadableDatabase();
                cursor = sqlDB.rawQuery("select hours,minutes from timelist where weekcode = '"+3+"';",null);



                while (cursor.moveToNext()){
                    try {
                        hours = cursor.getString(0);
                        min1 = cursor.getString(1);
                        int m=Integer.parseInt(min1);
                        int h=Integer.parseInt(hours);
                        if(m<0){

                            m1 = -m;
                            for(int i=0;0<m1;i++){
                                h1=h-1;
                                m1 = m1-60;
                            }
                            m1= 60 + m1;

                            if(m1<10&&h1<10){
                                dbmon2.setText("0"+h1+":0"+m1);
                            }else if(m1<10){
                                dbmon2.setText(h1+":0"+m1);
                            }else if(h1<10){
                                dbmon2.setText("0"+h1+":"+m1);
                            }else{
                                dbmon2.setText(h1+":"+m1);
                            }


                        }else{
                            if(m<10&&h<10){
                                dbmon2.setText("0"+h+":0"+m);
                            }else if(m<10){
                                dbmon2.setText(h+":0"+m);
                            }else if(h<10){
                                dbmon2.setText("0"+h+":"+m);
                            }else{
                                dbmon2.setText(h+":"+m);
                            }
                            //   dbmon5.setText(h+":"+m);
                        }

                    }catch (Exception ex){
                        hours = "xx";
                        min1 = "xx";
                    }

                }



                cursor.close();
                sqlDB.close();
                break ;
            case 4:
                day = "수";
                sqlDB = myHelper.getReadableDatabase();
                cursor = sqlDB.rawQuery("select hours,minutes from timelist where weekcode = '"+4+"';",null);



                while (cursor.moveToNext()){
                    try {
                        hours = cursor.getString(0);
                        min1 = cursor.getString(1);
                        int m=Integer.parseInt(min1);
                        int h=Integer.parseInt(hours);
                        if(m<0){

                            m1 = -m;
                            for(int i=0;0<m1;i++){
                                h1=h-1;
                                m1 = m1-60;
                            }
                            m1= 60 + m1;

                            if(m1<10&&h1<10){
                                dbmon3.setText("0"+h1+":0"+m1);
                            }else if(m1<10){
                                dbmon3.setText(h1+":0"+m1);
                            }else if(h1<10){
                                dbmon3.setText("0"+h1+":"+m1);
                            }else{
                                dbmon3.setText(h1+":"+m1);
                            }


                        }else{
                            if(m<10&&h<10){
                                dbmon3.setText("0"+h+":0"+m);
                            }else if(m<10){
                                dbmon3.setText(h+":0"+m);
                            }else if(h<10){
                                dbmon3.setText("0"+h+":"+m);
                            }else{
                                dbmon3.setText(h+":"+m);
                            }
                            //   dbmon5.setText(h+":"+m);
                        }

                    }catch (Exception ex){
                        hours = "xx";
                        min1 = "xx";
                    }

                }



                cursor.close();
                sqlDB.close();
                break ;
            case 5:
                day = "목";
                sqlDB = myHelper.getReadableDatabase();
                cursor = sqlDB.rawQuery("select hours,minutes from timelist where weekcode = '"+5+"';",null);



                while (cursor.moveToNext()){
                    try {
                        hours = cursor.getString(0);
                        min1 = cursor.getString(1);
                        int m=Integer.parseInt(min1);
                        int h=Integer.parseInt(hours);
                        if(m<0){

                            m1 = -m;
                            for(int i=0;0<m1;i++){
                                h1=h-1;
                                m1 = m1-60;
                            }
                            m1= 60 + m1;

                            if(m1<10&&h1<10){
                                dbmon4.setText("0"+h1+":0"+m1);
                            }else if(m1<10){
                                dbmon4.setText(h1+":0"+m1);
                            }else if(h1<10){
                                dbmon4.setText("0"+h1+":"+m1);
                            }else{
                                dbmon4.setText(h1+":"+m1);
                            }


                        }else{
                            if(m<10&&h<10){
                                dbmon4.setText("0"+h+":0"+m);
                            }else if(m<10){
                                dbmon4.setText(h+":0"+m);
                            }else if(h<10){
                                dbmon4.setText("0"+h+":"+m);
                            }else{
                                dbmon4.setText(h+":"+m);
                            }
                            //   dbmon5.setText(h+":"+m);
                        }

                    }catch (Exception ex){
                        hours = "xx";
                        min1 = "xx";
                    }

                }



                cursor.close();
                sqlDB.close();
                break ;
            case 6:
                day = "금";
                sqlDB = myHelper.getReadableDatabase();
                cursor = sqlDB.rawQuery("select hours,minutes from timelist where weekcode = '"+6+"';",null);



                while (cursor.moveToNext()){
                    try {
                        hours = cursor.getString(0);
                        min1 = cursor.getString(1);
                        int m=Integer.parseInt(min1);
                        int h=Integer.parseInt(hours);
                        if(m<0){

                            m1 = -m;
                            for(int i=0;0<m1;i++){
                                h1=h-1;
                                m1 = m1-60;
                            }
                            m1= 60 + m1;

                            if(m1<10&&h1<10){
                                dbmon5.setText("0"+h1+":0"+m1);
                            }else if(m1<10){
                                dbmon5.setText(h1+":0"+m1);
                            }else if(h1<10){
                                dbmon5.setText("0"+h1+":"+m1);
                            }else{
                                dbmon5.setText(h1+":"+m1);
                            }


                        }else{
                            if(m<10&&h<10){
                                dbmon5.setText("0"+h+":0"+m);
                            }else if(m<10){
                                dbmon5.setText(h+":0"+m);
                            }else if(h<10){
                                dbmon5.setText("0"+h+":"+m);
                            }else{
                                dbmon5.setText(h+":"+m);
                            }
                         //   dbmon5.setText(h+":"+m);
                        }

                    }catch (Exception ex){
                        hours = "xx";
                        min1 = "xx";
                    }

                }



                cursor.close();
                sqlDB.close();
                break ;
            case 7:
                day = "토";
                break ;

        }


        txt1.setText("알람 시간표");

        sqlDB.close();
    }
}
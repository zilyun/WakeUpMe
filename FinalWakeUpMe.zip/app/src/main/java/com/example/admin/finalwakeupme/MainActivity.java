package com.example.admin.finalwakeupme;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.nfc.Tag;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import static com.example.admin.finalwakeupme.R.drawable.gra;

public class MainActivity extends AppCompatActivity {

    LinearLayout linearLayout;

    Thread thread;
    AlarmManager mAlarmManager, mAlarmManager1;
    Intent mAlarmIntent, mAlarmIntent1;
    PendingIntent mPendingIntent, mPendingIntent1;
    private ArrayList<MusicDto> list;
    ImageButton btn;
    Button btn1, btn2;
    TextView txt1;
    Calendar calendar = Calendar.getInstance();
    TextView editText1, editText2, editText3, editText4, editText5;
    int valume;
    SeekBar seekVolumn;

    TextView prepare, go;
    EditText hours3, hours4;

    ContentResolver res;
    int position;
    String day = "";
    int hours, hours1, min = 0;
    String s1 = Integer.toString(hours);
    String s2 = Integer.toString(min);
    TabHost th;


    TextView alram1, alram2;

    ImageButton imgbtn1, imgbtn2;
    ImageButton hoursup, hoursdown;
    ImageButton minup, mindown;

    int hoursint1, hoursint2 = 0;
    int sigan1, sigan2 = 0;
    int bun1, bun2 = 0;

    Cursor cursor;
    myDBHelper myHelper;
    SQLiteDatabase sqlDB;


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            position = data.getIntExtra("position", 0);
            list = (ArrayList<MusicDto>) data.getSerializableExtra("playlist");
        } else {
            System.out.println("실패");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        myHelper = new myDBHelper(MainActivity.this, "TEST", null, 1);
        sqlDB = myHelper.getWritableDatabase();
        myHelper.onUpgrade(sqlDB, 1, 2);
        sqlDB.close();


        calendar.setTimeInMillis(System.currentTimeMillis());

        linearLayout = (LinearLayout) findViewById(R.id.LinearMain);

        btn = (ImageButton) findViewById(R.id.btn);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        txt1 = (TextView) findViewById(R.id.txt1);
        res = getContentResolver();
        // editText1 = (EditText) findViewById(R.id.edit1);
        // editText2 = (EditText) findViewById(R.id.edit2);
        // editText3 = (EditText) findViewById(R.id.edit3);
        editText4 = (TextView) findViewById(R.id.edit4);
        editText5 = (TextView) findViewById(R.id.edit5);

        imgbtn1 = (ImageButton) findViewById(R.id.imgbtn1);
        imgbtn2 = (ImageButton) findViewById(R.id.imgbtn2);

        hoursup = (ImageButton) findViewById(R.id.hourup);
        hoursdown = (ImageButton) findViewById(R.id.hourdown);

        minup = (ImageButton) findViewById(R.id.minup);
        mindown = (ImageButton) findViewById(R.id.mindown);

        hours3 = (EditText) findViewById(R.id.hours1);
        hours4 = (EditText) findViewById(R.id.hours2);

        prepare = (TextView) findViewById(R.id.prepare);
        go = (TextView) findViewById(R.id.go);


        alram1 = (TextView) findViewById(R.id.alram1234);
        alram2 = (TextView) findViewById(R.id.alram123);

        Typeface face = Typeface.createFromAsset(getAssets(), "fonts/itgirl.ttf");
        btn1.setTypeface(face);
        btn2.setTypeface(face);
        txt1.setTypeface(face);
        editText4.setTypeface(face);
        editText5.setTypeface(face);
        hours3.setTypeface(face);
        hours4.setTypeface(face);
        go.setTypeface(face);
        prepare.setTypeface(face);
        alram1.setTypeface(face);
        alram2.setTypeface(face);
        //   th.setTypeface(face);


        seekVolumn = (SeekBar) findViewById(R.id.SeekBar_Volumn);
        final AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        int nMax = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int nCurrentVolumn = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        seekVolumn.setMax(nMax);
        seekVolumn.setProgress(nCurrentVolumn);
        seekVolumn.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {


            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
// TODO Auto-generated method stub
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
// TODO Auto-generated method stub
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
// TODO Auto-generated method stub
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
                valume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            }

        });


        editText4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                AlertDialog.Builder ad = new AlertDialog.Builder(MainActivity.this);

                ad.setTitle("시간 입력");       // 제목 설정
                ad.setMessage("");   // 내용 설정

// EditText 삽입하기
                final EditText et = new EditText(MainActivity.this);
                ad.setView(et);


// 취소 버튼 설정
                ad.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();     //닫기
                        // Event
                    }
                });

                // 확인 버튼 설정
                ad.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                        try { // Text 값 받아서 로그 남기기

                            hours = Integer.parseInt(et.getText().toString());
                            if (0 <= hours && hours < 12) {
                                s1 = Integer.toString(hours);
                                editText4.setText(s1);
                                dialog.dismiss();     //닫기
                            } else {
                                Toast.makeText(getApplicationContext(), "0시부터 12시만 입력 가능", Toast.LENGTH_SHORT).show();
                            }
                            // Event
                        } catch (Exception ex) {
                            Toast.makeText(getApplicationContext(), "제대로 입력하시오", Toast.LENGTH_SHORT).show();
                        }
                    }
                });


// 창 띄우기
                ad.show();


            }
        });


        editText5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                AlertDialog.Builder ad = new AlertDialog.Builder(MainActivity.this);

                ad.setTitle("분 입력");       // 제목 설정
                ad.setMessage("");   // 내용 설정

// EditText 삽입하기
                final EditText et = new EditText(MainActivity.this);
                ad.setView(et);


// 취소 버튼 설정
                ad.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();     //닫기
                        // Event
                    }
                });

                // 확인 버튼 설정
                ad.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                        try { // Text 값 받아서 로그 남기기

                            min = Integer.parseInt(et.getText().toString());
                            if (0 <= min && min < 60) {
                                s2 = Integer.toString(min);
                                editText5.setText(s2);
                                dialog.dismiss();     //닫기
                            } else {
                                Toast.makeText(getApplicationContext(), "0분부터 60분까지 입력 가능", Toast.LENGTH_SHORT).show();
                            }
                            // Event
                        } catch (Exception ex) {
                            Toast.makeText(getApplicationContext(), "제대로 입력하시오", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

// 창 띄우기
                ad.show();


            }
        });


        try {
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent intent = new Intent(MainActivity.this, ListActivity.class);
                        startActivityForResult(intent, 0);
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "노래가 없습니다.", Toast.LENGTH_SHORT).show();
                    }

                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MyService.class);
                stopService(intent);
                if (mAlarmManager != null) {
                    mAlarmManager.cancel(mPendingIntent);
                    mPendingIntent.cancel();
                    Toast.makeText(getApplicationContext(), "알람해제!", Toast.LENGTH_SHORT).show();
                    mAlarmManager = null;

                } else {
                    Toast.makeText(getApplicationContext(), "저장된 알람이 없습니다.", Toast.LENGTH_SHORT).show();
                }


            }
        });


        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // 알람 매니저에 등록할 인텐트를 만듬

                //     year = Integer.parseInt(editText1.getText().toString());
                //      month = Integer.parseInt(editText2.getText().toString());
                try {

                    if (!editText4.getText().toString().equals("") && !hours3.getText().toString().equals("")
                            && !hours4.getText().toString().equals("") && !editText5.getText().toString().equals("")
                            && list != null) {


                        //   System.out.println(editText3.getText().toString());


                        //    day = Integer.parseInt(editText3.getText().toString());
                        hours = Integer.parseInt(editText4.getText().toString());
                        min = Integer.parseInt(editText5.getText().toString());


                        hours = hours + hours1;

                        hoursint1 = Integer.parseInt(hours3.getText().toString());

                        sigan1 = hoursint1 / 60;
                        bun1 = hoursint1 % 60;

                        System.out.println(hoursint1);
                        hoursint2 = Integer.parseInt(hours4.getText().toString());

                        sigan2 = hoursint2 / 60;
                        bun2 = hoursint2 % 60;

                        System.out.println(hoursint2);


                        hours = hours - sigan2 - sigan1;
                        min = min - bun1 - bun2;


                        System.out.println(hours);
                        System.out.println(min);



           /*     calendar.set(Calendar.YEAR, year);
                switch (month) {
                    case 1:
                        calendar.set(Calendar.MONTH, Calendar.JANUARY);
                        break;
                    case 2:
                        calendar.set(Calendar.MONTH, Calendar.FEBRUARY);
                        break;
                    case 3:
                        calendar.set(Calendar.MONTH, Calendar.MARCH);
                        break;
                    case 4:
                        calendar.set(Calendar.MONTH, Calendar.APRIL);
                        break;
                    case 5:
                        calendar.set(Calendar.MONTH, Calendar.MAY);
                        break;
                    case 6:
                        calendar.set(Calendar.MONTH, Calendar.JUNE);
                        break;
                    case 7:
                        calendar.set(Calendar.MONTH, Calendar.JULY);
                        break;
                    case 8:
                        calendar.set(Calendar.MONTH, Calendar.AUGUST);
                        break;
                    case 9:
                        calendar.set(Calendar.MONTH, Calendar.SEPTEMBER);
                        break;
                    case 10:
                        calendar.set(Calendar.MONTH, Calendar.OCTOBER);
                        break;
                    case 11:
                        calendar.set(Calendar.MONTH, Calendar.NOVEMBER);
                        break;
                    case 12:
                        calendar.set(Calendar.MONTH, Calendar.DECEMBER);
                        break;

                }*/
                        //   calendar.add(Calendar.DATE,1);
                        calendar.set(Calendar.HOUR_OF_DAY, hours);
                        calendar.set(Calendar.MINUTE, min);
                        calendar.set(Calendar.SECOND, 0);
                        calendar.set(Calendar.MILLISECOND, 0);
                        //    calendar.add(Calendar.HOUR_OF_DAY, -sigan1);
                        //     calendar.add(Calendar.HOUR_OF_DAY, -sigan2);
                        //    calendar.add(Calendar.MINUTE, -bun1);
                        //    calendar.add(Calendar.MINUTE, -bun2);

                        long aTime = System.currentTimeMillis();
                        long bTime = calendar.getTimeInMillis();


                        //하루의 시간을 나타냄
                        long interval = 1000 * 60 * 60 * 24;

                        //만일 내가 설정한 시간이 현재 시간보다 작다면 알람이 바로 울려버리기 때문에 이미 시간이 지난 알람은 다음날 울려야 한다.
                        while (aTime > bTime) {
                            bTime += interval;
                        }


                        mAlarmIntent = new Intent("com.test.alarmtestous.ALARM_START");
                        mAlarmIntent.putExtra("position", position);
                        mAlarmIntent.putExtra("playlist", list);
                        mAlarmIntent.putExtra("valume", valume);


                        int dayNum = calendar.get(Calendar.DAY_OF_WEEK);


                        switch (dayNum) {
                            case 1:
                                day = "일";
                                try {
                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("insert into timelist values('" + 1 + "','" + hours + "','" + min + "');");
                                    sqlDB.close();
                                } catch (Exception ex) {


                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("update timelist set hours='" + hours + "',minutes='" + min + "' where weekcode = '1'");
                                    //sqlDB.execSQL("delete from timelist where weekcode = '" + 5 + "';");
                                    //sqlDB.execSQL("insert into timelist values('" + 5 + "','" + hours + "','" + min + "');");


                                    sqlDB.close();

                                }
                                break;
                            case 2:
                                day = "월";
                                try {
                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("insert into timelist values('" + 2 + "','" + hours + "','" + min + "');");
                                    sqlDB.close();
                                } catch (Exception ex) {


                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("update timelist set hours='" + hours + "',minutes='" + min + "' where weekcode = '2'");
                                    //sqlDB.execSQL("delete from timelist where weekcode = '" + 5 + "';");
                                    //sqlDB.execSQL("insert into timelist values('" + 5 + "','" + hours + "','" + min + "');");


                                    sqlDB.close();

                                }
                                break;
                            case 3:
                                day = "화";
                                try {
                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("insert into timelist values('" + 3 + "','" + hours + "','" + min + "');");
                                    sqlDB.close();
                                } catch (Exception ex) {


                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("update timelist set hours='" + hours + "',minutes='" + min + "' where weekcode = '3'");
                                    //sqlDB.execSQL("delete from timelist where weekcode = '" + 5 + "';");
                                    //sqlDB.execSQL("insert into timelist values('" + 5 + "','" + hours + "','" + min + "');");


                                    sqlDB.close();

                                }
                                break;
                            case 4:
                                day = "수";
                                try {
                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("insert into timelist values('" + 4 + "','" + hours + "','" + min + "');");
                                    sqlDB.close();
                                } catch (Exception ex) {


                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("update timelist set hours='" + hours + "',minutes='" + min + "' where weekcode = '4'");
                                    //sqlDB.execSQL("delete from timelist where weekcode = '" + 5 + "';");
                                    //sqlDB.execSQL("insert into timelist values('" + 5 + "','" + hours + "','" + min + "');");


                                    sqlDB.close();

                                }
                                break;
                            case 5:
                                day = "목";
                                try {
                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("insert into timelist values('" + 5 + "','" + hours + "','" + min + "');");
                                    sqlDB.close();
                                } catch (Exception ex) {


                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("update timelist set hours='" + hours + "',minutes='" + min + "' where weekcode = '5'");
                                    //sqlDB.execSQL("delete from timelist where weekcode = '" + 5 + "';");
                                    //sqlDB.execSQL("insert into timelist values('" + 5 + "','" + hours + "','" + min + "');");


                                    sqlDB.close();

                                }
                                break;
                            case 6:
                                day = "금";
                                try {
                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("insert into timelist values('" + 6 + "','" + hours + "','" + min + "');");
                                    sqlDB.close();
                                } catch (Exception ex) {


                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("update timelist set hours='" + hours + "',minutes='" + min + "' where weekcode = '6'");
                                    //sqlDB.execSQL("delete from timelist where weekcode = '" + 5 + "';");
                                    //sqlDB.execSQL("insert into timelist values('" + 5 + "','" + hours + "','" + min + "');");


                                    sqlDB.close();

                                }
                                break;
                            case 7:
                                day = "토";
                                try {
                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("insert into timelist values('" + 7 + "','" + hours + "','" + min + "');");
                                    sqlDB.close();
                                } catch (Exception ex) {


                                    sqlDB = myHelper.getWritableDatabase();
                                    sqlDB.execSQL("update timelist set hours='" + hours + "',minutes='" + min + "' where weekcode = '7'");
                                    //sqlDB.execSQL("delete from timelist where weekcode = '" + 5 + "';");
                                    //sqlDB.execSQL("insert into timelist values('" + 5 + "','" + hours + "','" + min + "');");


                                    sqlDB.close();

                                }
                                break;

                        }


                        //        date.setDate(date.getDate()+1);


                        long diff = bTime - System.currentTimeMillis();

                        long diffmillis = diff % 1000;
                        diff /= 1000;
                        long diffsecond = diff % 60;
                        diff /= 60;
                        long diffminutes = diff % 60;
                        diff /= 60;
                        long diffHours = diff;


                        mPendingIntent = PendingIntent.getBroadcast(
                                MainActivity.this,
                                0,
                                mAlarmIntent,
                                PendingIntent.FLAG_CANCEL_CURRENT
                        ); // 요청코드 번호를 다르게 하면 여러개 가능!

                        mAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                        mAlarmManager.set(
                                AlarmManager.RTC_WAKEUP, bTime, mPendingIntent
                        );


                        min = 0;
                        hours = 0;

                        //      Toast.makeText(getApplicationContext(), "알람 설정!", Toast.LENGTH_SHORT).show();
                        Toast.makeText(getApplicationContext(), "알람이 " + diffHours + "시 " + diffminutes + "분 " + diffsecond + "초 뒤에 울립니다.", Toast.LENGTH_LONG).show();

                        diffHours = 0;
                        diffminutes = 0;
                        diffsecond = 0;
                        //Intent intent = new Intent(getApplicationContext(), MyService.class);
                        //intent.putExtra("time", calendar.getTimeInMillis());
                        //startService(intent);


                    } else {
                        Toast.makeText(getApplicationContext(), "제대로 입력하세요.", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Toast.makeText(getApplicationContext(), "숫자를 입력하세요", Toast.LENGTH_LONG).show();
                }

            }
        });


        thread = new Thread() {

            @Override
            public void run() {
                while (!isInterrupted()) {

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Date date = new Date(System.currentTimeMillis() + 1000);
                            //        date.setDate(date.getDate()+1);
                            SimpleDateFormat format = new SimpleDateFormat("yyyy년 MM월 dd일 hh시 mm분 ss초");
                            String time = format.format(date);
                            txt1.setText(time);
                        }
                    });
                    try {
                        Thread.sleep(1000); // 1000 ms = 1초
                        // 스레드를 1초동안 잠들게 함
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } // while
            } // run()
        }

        ; // new Thread() { };
        thread.start();


        hoursup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hours < 12)
                    hours = hours + 1;
                s1 = Integer.toString(hours);
                editText4.setText(s1);
            }
        });

        hoursdown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hours > 0)
                    hours = hours - 1;
                s1 = Integer.toString(hours);
                editText4.setText(s1);
            }
        });

        minup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (min < 59)
                    min = min + 1;
                s2 = Integer.toString(min);
                editText5.setText(s2);
            }
        });

        mindown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (min > 0)
                    min = min - 1;
                s2 = Integer.toString(min);
                editText5.setText(s2);

            }
        });


        imgbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgbtn1.setVisibility(View.GONE);
                imgbtn2.setVisibility(View.VISIBLE);
                if (hours1 == 0) {
                    hours1 = hours1 + 12;
                }
                linearLayout.setBackgroundResource(R.drawable.gra4);

            }
        });

        imgbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgbtn1.setVisibility(View.VISIBLE);
                imgbtn2.setVisibility(View.GONE);
                if (hours1 == 12) {
                    hours1 = hours1 - 12;
                }
                linearLayout.setBackgroundResource(R.drawable.gra);
            }
        });


        th = (TabHost) findViewById(R.id.th);
        th.setup();

        TabHost.TabSpec ts1 = th.newTabSpec("Tab1");
        ts1.setIndicator("시간설정");
        ts1.setContent(R.id.tab_view1);
        th.addTab(ts1);

        TabHost.TabSpec ts2 = th.newTabSpec("Tab2");
        ts2.setIndicator("알람설정");

        ts2.setContent(R.id.tab_view2);
        th.addTab(ts2);

        th.setCurrentTab(0);

        Typeface face1 = Typeface.createFromAsset(getAssets(), "fonts/itgirl.ttf");

        for (int i = 0; i < th.getTabWidget().getChildCount(); i++) {
            //th.getTabWidget().getChildAt(i).setBackgroundResource(R.drawable.);
            TextView tv = (TextView) th.getTabWidget().getChildAt(i).findViewById(android.R.id.title);
            tv.setTextSize(15);
            tv.setTextColor(Color.DKGRAY);
            tv.setTypeface(face1);
        }


        th.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {
                if (tabId.equals("tab1")) {


                } else if (tabId.equals("tab2")) {


                }
            }
        });


    }


}

package com.example.admin.finalwakeupme;

/**
 * Created by Admin on 2018-05-21.
 */


import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.GlideDrawableImageViewTarget;

/**
 * Created by Admin on 2018-05-21.
 */

public class IntroActivity extends Activity {
    private Handler handler;
    Animation animation,animation1;
    ImageView imageView,imageView1,back;
    TextView tx;
    ImageView good,good1;

    Runnable runnable = new Runnable() {
        @Override
        public void run() {

            Intent intent = new Intent(IntroActivity.this, MainActivity1.class);
            startActivity(intent);
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        back = (ImageView) findViewById(R.id.back);

     //   imageView = (ImageView)findViewById(R.id.img);
   //     imageView1 = (ImageView)findViewById(R.id.img1);

    //    good = (ImageView)findViewById(R.id.good);
      //  good1 = (ImageView)findViewById(R.id.good1);

        tx = (TextView)findViewById(R.id.txt123);

        Typeface face=Typeface.createFromAsset(getAssets(), "fonts/itgirl.ttf");
        tx.setTypeface(face);

        animation = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anim);
        animation1 = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anim1);
       // imageView.startAnimation(animation);


       // Glide.with(this).load(R.raw.reracbackg).into(back);
      //  Glide.with(this).load(R.raw.rerac).into(imageView1);

        Glide.with(this).load(R.drawable.wakeup).into(back);
        GlideDrawableImageViewTarget imageViewTarget = new GlideDrawableImageViewTarget(back);
        Glide.with(this).load(R.raw.wakeup).into(imageViewTarget);



        tx.startAnimation(animation);
     //   good.startAnimation(animation1);
      //  good1.startAnimation(animation1);
        tx.setVisibility(View.INVISIBLE);
     //   good.setVisibility(View.INVISIBLE);
    //    good1.setVisibility(View.INVISIBLE);
        init();


        handler.postDelayed(runnable, 5000);


    }

    public void init() {
        handler = new Handler();
    }

    @Override
    public void onBackPressed(){
        super.onBackPressed();
        handler.removeCallbacks(runnable);
    }
}
